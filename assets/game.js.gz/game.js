(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const wait = (ms) => new Promise(r => setTimeout(r, ms));

  const SKIN = { light:'#f2ccb0', warm:'#d7aa87', tan:'#b77a57', deep:'#895943' };
  const HAIR = { darkbrown:'#2c211f', black:'#151820', wine:'#713742', gold:'#b57b3d' };
  const EYES = { brown:'#5a4138', violet:'#6b5ab6', green:'#467970', blue:'#477ca6' };
  const CLOTH = { navy:'#243b59', purple:'#463158', green:'#3b503d', burgundy:'#56313a' };

  const DEFAULT_STATE = () => ({
    version: 3,
    scene: 'gate',
    difficulty: null,
    name: '지우',
    gender: 'female',
    appearance: { skin:'light', eyes:'brown', nose:'small', mouth:'smile', hair:'soft', hairColor:'darkbrown', outfit:'navy' },
    hp: 1000,
    maxHp: 1000,
    lives: 5,
    attack: 40,
    weapon: '없음',
    armor: 0,
    keys: 0,
    mood: '긴장',
    inventory: [],
    firstPerson: true,
    easy: { cafeteriaClosed:false, toiletClosed:false, toiletGhostDead:false, exitSpawned:false },
    normal: { dogName:null, crafted:false, restroomKey:false, principalKills:0, scienceFragments:0, frogDone:false, deskDone:false, skeletonDone:false, friendName:null, friendGender:null, friendAppearance:0, goldenKey:false },
    challenge: { restroomKey:false, cerberusDone:false, blue:0, green:0, englishDone:false, mathDone:false, peDone:false, rooftopDone:false, frameDone:false },
    achievements: { watcherBadge:false },
    settings: { sound:true, shake:true, scare:'full', reducedMotion:false },
    checkpoint: 'gate'
  });

  const refs = {
    sceneCanvas: $('sceneCanvas'), sceneFx: $('sceneFx'), flashLayer: $('flashLayer'),
    titleScreen: $('titleScreen'), creatorScreen: $('creatorScreen'), gameScreen: $('gameScreen'),
    topBar: $('topBar'), hud: $('hud'), areaLabel: $('areaLabel'), objectiveLabel: $('objectiveLabel'),
    interactionLayer: $('interactionLayer'), viewToggleBtn: $('viewToggleBtn'),
    hudName: $('hudName'), hudMood: $('hudMood'), hpText: $('hpText'), hpFill: $('hpFill'), livesDisplay: $('livesDisplay'),
    attackText: $('attackText'), weaponText: $('weaponText'), armorText: $('armorText'), keyText: $('keyText'), inventoryMini: $('inventoryMini'),
    dialogueBox: $('dialogueBox'), dialogueSpeaker: $('dialogueSpeaker'), dialogueEmotion: $('dialogueEmotion'), dialogueText: $('dialogueText'), choiceGrid: $('choiceGrid'), dialoguePortrait: $('dialoguePortrait'),
    toast: $('toast'), modalBackdrop: $('modalBackdrop'), lockModal: $('lockModal'), lockDisplay: $('lockDisplay'), keypad: $('keypad'),
    settingsModal: $('settingsModal'), soundToggle: $('soundToggle'), shakeToggle: $('shakeToggle'), scareSelect: $('scareSelect'), motionToggle: $('motionToggle'),
    nameModal: $('nameModal'), nameModalTitle: $('nameModalTitle'), nameModalDescription: $('nameModalDescription'), nameModalInput: $('nameModalInput'), nameModalConfirm: $('nameModalConfirm'),
    endingModal: $('endingModal'), endingTitle: $('endingTitle'), endingText: $('endingText'), endingReward: $('endingReward'), endingActions: $('endingActions'), endingKicker: $('endingKicker'),
    quickTimeModal: $('quickTimeModal'), quickFill: $('quickFill'), mashBtn: $('mashBtn'), mashCount: $('mashCount'), quickText: $('quickText'),
    avatarPreview: $('avatarPreview'), creatorPreviewName: $('creatorPreviewName'), miniAvatar: $('miniAvatar')
  };

  class AudioEngine {
    constructor(getSettings) { this.ctx = null; this.ambient = null; this.getSettings = getSettings; }
    ensure() {
      if (this.getSettings && !this.getSettings().sound) return null;
      if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return this.ctx;
    }
    tone(freq=220, dur=.12, type='sine', gain=.035) {
      const ctx = this.ensure(); if (!ctx) return;
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.type = type; o.frequency.value = freq; g.gain.value = gain;
      o.connect(g); g.connect(ctx.destination); o.start(); g.gain.exponentialRampToValueAtTime(.0001, ctx.currentTime + dur); o.stop(ctx.currentTime + dur);
    }
    click() { this.tone(520,.05,'triangle',.02); }
    lock() { this.tone(125,.14,'square',.035); setTimeout(()=>this.tone(92,.22,'sawtooth',.025),80); }
    success() { [392,523,659].forEach((f,i)=>setTimeout(()=>this.tone(f,.18,'triangle',.035),i*90)); }
    danger() { this.tone(72,.34,'sawtooth',.06); setTimeout(()=>this.tone(54,.38,'square',.035),60); }
    startAmbient() {
      const ctx = this.ensure(); if (!ctx || this.ambient) return;
      const osc = ctx.createOscillator(); const gain = ctx.createGain(); const filter = ctx.createBiquadFilter();
      osc.type = 'sine'; osc.frequency.value = 47; gain.gain.value = .012; filter.type = 'lowpass'; filter.frequency.value = 150;
      osc.connect(filter); filter.connect(gain); gain.connect(ctx.destination); osc.start();
      this.ambient = { osc, gain };
    }
    stopAmbient() { if (this.ambient) { try { this.ambient.osc.stop(); } catch {} this.ambient = null; } }
  }

  class SceneRenderer {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.time = 0;
      this.scene = 'gate';
      this.resize();
      window.addEventListener('resize', () => this.resize());
      requestAnimationFrame(t => this.loop(t));
    }
    resize() {
      const r = this.canvas.getBoundingClientRect();
      this.canvas.width = Math.max(1, Math.floor(r.width * this.dpr));
      this.canvas.height = Math.max(1, Math.floor(r.height * this.dpr));
      this.ctx.setTransform(this.dpr,0,0,this.dpr,0,0);
      this.w = r.width; this.h = r.height;
    }
    set(scene) { this.scene = scene; }
    loop(t) { this.time = t/1000; this.draw(); requestAnimationFrame(tt => this.loop(tt)); }
    gradient(y1,c1,y2,c2) { const g=this.ctx.createLinearGradient(0,y1,0,y2); g.addColorStop(0,c1); g.addColorStop(1,c2); return g; }
    draw() {
      const c = this.ctx, w=this.w, h=this.h, t=this.time;
      c.clearRect(0,0,w,h);
      switch(this.scene) {
        case 'gate': this.drawGate(c,w,h,t); break;
        case 'lobby': this.drawLobby(c,w,h,t); break;
        case 'easyHall': this.drawCorridor(c,w,h,t,'#23313a','#161d23', true); break;
        case 'cafeteria': this.drawCafeteria(c,w,h,t); break;
        case 'toilet': this.drawToilet(c,w,h,t); break;
        case 'normalEntry': this.drawCorridor(c,w,h,t,'#283039','#141a20'); break;
        case 'normalHall': this.drawCorridor(c,w,h,t,'#29323a','#12191e'); break;
        case 'principal': this.drawOffice(c,w,h,t); break;
        case 'science': this.drawScience(c,w,h,t); break;
        case 'challengeEntry': this.drawNewBuilding(c,w,h,t); break;
        case 'english': this.drawClassroom(c,w,h,t,'ENGLISH'); break;
        case 'stairs': this.drawStairs(c,w,h,t); break;
        case 'math': this.drawClassroom(c,w,h,t,'MATH'); break;
        case 'pe': this.drawGym(c,w,h,t); break;
        case 'rooftop': this.drawRooftop(c,w,h,t); break;
        case 'void': this.drawVoid(c,w,h,t); break;
        default: this.drawCorridor(c,w,h,t,'#22303a','#11171c');
      }
      this.drawFog(c,w,h,t);
    }
    drawFog(c,w,h,t) {
      c.save(); c.globalAlpha=.08;
      for(let i=0;i<7;i++){
        const x=((i*197 + t*18*(i%2?1:-1))%(w+280))-140;
        const y=h*.56 + Math.sin(t*.34+i)*40 + i*20;
        const g=c.createRadialGradient(x,y,0,x,y,150); g.addColorStop(0,'#bfd9e8'); g.addColorStop(1,'transparent'); c.fillStyle=g; c.beginPath(); c.arc(x,y,150,0,Math.PI*2); c.fill();
      }
      c.restore();
    }
    drawGate(c,w,h,t) {
      c.fillStyle=this.gradient(0,'#17324a',h*.58,'#08121c'); c.fillRect(0,0,w,h);
      c.fillStyle='#0a0f14'; c.fillRect(0,h*.62,w,h*.38);
      const bx=w*.1, by=h*.2, bw=w*.8, bh=h*.44;
      c.fillStyle='#18242e'; c.fillRect(bx,by,bw,bh);
      c.fillStyle='#213341'; c.beginPath(); c.moveTo(bx,by); c.lineTo(w*.28,h*.11); c.lineTo(w*.64,h*.11); c.lineTo(bx+bw,by); c.fill();
      const rows=2, cols=8; for(let r=0;r<rows;r++) for(let col=0;col<cols;col++){
        const ww=bw*.065, wh=bh*.14, x=bx+bw*.08+col*bw*.105, y=by+bh*.18+r*bh*.28;
        const flick=(Math.sin(t*1.7+col*3+r*7)> .86); c.fillStyle=flick?'#d5c98d':'#233d4d'; c.fillRect(x,y,ww,wh);
        c.strokeStyle='#071017'; c.lineWidth=3; c.strokeRect(x,y,ww,wh);
      }
      c.fillStyle='#0c1116'; c.fillRect(w*.43,h*.48,w*.14,h*.16);
      c.strokeStyle='#465663'; c.lineWidth=3; for(let i=0;i<14;i++){const x=w*.25+i*w*.035;c.beginPath();c.moveTo(x,h*.49);c.lineTo(x,h*.75);c.stroke();}
      c.beginPath();c.moveTo(w*.23,h*.49);c.lineTo(w*.77,h*.49);c.stroke();c.beginPath();c.moveTo(w*.23,h*.61);c.lineTo(w*.77,h*.61);c.stroke();
      c.fillStyle='#06080b'; c.fillRect(w*.487,h*.55,24,28); c.strokeStyle='#d7ad56'; c.strokeRect(w*.487,h*.55,24,28);
      c.fillStyle='rgba(112,178,223,.16)'; c.beginPath(); c.ellipse(w*.82,h*.22,140,80,-.25,0,Math.PI*2); c.fill();
    }
    drawLobby(c,w,h,t) {
      this.drawCorridor(c,w,h,t,'#273744','#111920');
      const labels=['급식실','본관','신관']; const xs=[.24,.5,.76];
      labels.forEach((lab,i)=>{ const x=w*xs[i]; c.fillStyle='#0a0e13'; c.fillRect(x-w*.065,h*.37,w*.13,h*.28); c.strokeStyle=i===2?'#4b6070':'#3a4c59'; c.lineWidth=4; c.strokeRect(x-w*.065,h*.37,w*.13,h*.28); c.fillStyle='#9fb0bd'; c.font='700 13px sans-serif'; c.textAlign='center'; c.fillText(lab,x,h*.34); });
    }
    drawCorridor(c,w,h,t,wall='#26323b',far='#12181d',windows=false) {
      c.fillStyle=far; c.fillRect(0,0,w,h);
      const horizon=h*.43;
      c.fillStyle=wall; c.beginPath(); c.moveTo(0,0); c.lineTo(w*.27,horizon); c.lineTo(w*.27,h); c.lineTo(0,h); c.fill();
      c.fillStyle='#202a31'; c.beginPath(); c.moveTo(w,0); c.lineTo(w*.73,horizon); c.lineTo(w*.73,h); c.lineTo(w,h); c.fill();
      c.fillStyle='#172129'; c.beginPath(); c.moveTo(w*.27,horizon); c.lineTo(w*.73,horizon); c.lineTo(w*.83,h); c.lineTo(w*.17,h); c.fill();
      c.strokeStyle='rgba(173,203,222,.11)'; c.lineWidth=1;
      for(let i=1;i<10;i++){const y=horizon+(h-horizon)*(i/10)**1.7;c.beginPath();c.moveTo(w*.2,y);c.lineTo(w*.8,y);c.stroke();}
      for(let i=0;i<7;i++){const x=w*.27+(w*.46)*(i/6); c.beginPath(); c.moveTo(x,horizon); c.lineTo(w*.5+(x-w*.5)*1.55,h); c.stroke();}
      c.fillStyle='rgba(191,219,235,.12)'; c.fillRect(w*.44,h*.11,w*.12,9); if(Math.sin(t*7)>.92) c.fillStyle='rgba(220,234,185,.25)'; else c.fillStyle='rgba(178,211,228,.1)'; c.fillRect(w*.46,h*.12,w*.08,h*.16);
      for(let i=0;i<4;i++){
        const y=h*.22+i*h*.135, scale=1-i*.11;
        c.fillStyle='#0c1116'; c.fillRect(w*.07,y,w*.13*scale,h*.1*scale); c.strokeStyle='#34444f'; c.strokeRect(w*.07,y,w*.13*scale,h*.1*scale);
        if(windows){ c.fillStyle='rgba(93,150,181,.19)'; c.fillRect(w*.81,y,w*.11*scale,h*.09*scale); }
      }
    }
    drawCafeteria(c,w,h,t) {
      this.drawCorridor(c,w,h,t,'#30363a','#14181b');
      c.fillStyle='#2b3438'; c.fillRect(w*.29,h*.39,w*.42,h*.23);
      c.fillStyle='#59676b'; for(let i=0;i<4;i++) c.fillRect(w*.32+i*w*.1,h*.45,w*.075,h*.04);
      c.fillStyle='#a87c4a'; for(let i=0;i<3;i++){ c.fillRect(w*.34+i*w*.15,h*.67,w*.1,7); c.fillRect(w*.36+i*w*.15,h*.67,5,h*.08); c.fillRect(w*.42+i*w*.15,h*.67,5,h*.08); }
      if(Math.sin(t*1.5)>.8){ c.fillStyle='rgba(235,210,165,.08)'; c.fillRect(w*.46,h*.15,w*.08,h*.2); }
    }
    drawToilet(c,w,h,t) {
      c.fillStyle=this.gradient(0,'#29404b',h,'#10181d'); c.fillRect(0,0,w,h);
      c.fillStyle='#45555c'; for(let y=0;y<h;y+=42){c.fillRect(0,y,w,1);} for(let x=0;x<w;x+=72){c.fillRect(x,0,1,h);}
      c.fillStyle='#d3d7d3'; c.fillRect(w*.18,h*.48,w*.19,h*.07); c.fillStyle='#88999d'; c.fillRect(w*.24,h*.39,w*.07,h*.09);
      c.fillStyle='#d5d7d2'; c.beginPath(); c.ellipse(w*.68,h*.63,w*.07,h*.04,0,0,Math.PI*2); c.fill(); c.fillRect(w*.61,h*.48,w*.14,h*.15);
      c.fillStyle='rgba(15,26,31,.82)'; c.beginPath(); c.ellipse(w*.68,h*.62,w*.05,h*.022,0,0,Math.PI*2); c.fill();
    }
    drawOffice(c,w,h,t) {
      c.fillStyle=this.gradient(0,'#3a302e',h,'#171414'); c.fillRect(0,0,w,h); c.fillStyle='#312722'; c.fillRect(w*.13,h*.18,w*.74,h*.48);
      c.fillStyle='#181414'; c.fillRect(w*.35,h*.19,w*.3,h*.2); c.strokeStyle='#8c6c3f'; c.lineWidth=6; c.strokeRect(w*.35,h*.19,w*.3,h*.2);
      c.fillStyle='#4a3425'; c.fillRect(w*.3,h*.58,w*.4,h*.08); c.fillRect(w*.34,h*.66,8,h*.12); c.fillRect(w*.65,h*.66,8,h*.12);
      c.fillStyle='rgba(255,215,132,.09)'; c.beginPath(); c.arc(w*.5,h*.1,80,0,Math.PI*2); c.fill();
    }
    drawScience(c,w,h,t) {
      this.drawClassroom(c,w,h,t,'SCIENCE'); c.fillStyle='#7b8b8a'; c.fillRect(w*.14,h*.55,w*.18,h*.06); c.fillRect(w*.68,h*.55,w*.18,h*.06);
      c.strokeStyle='rgba(144,227,255,.28)'; c.lineWidth=3; c.beginPath(); c.moveTo(w*.5,h*.55); c.lineTo(w*.48,h*.64); c.lineTo(w*.52,h*.64); c.closePath(); c.stroke();
      c.fillStyle='rgba(94,224,255,.12)'; c.beginPath(); c.arc(w*.5,h*.6,26+Math.sin(t*2)*3,0,Math.PI*2); c.fill();
    }
    drawNewBuilding(c,w,h,t) {
      c.fillStyle=this.gradient(0,'#1d2b42',h*.6,'#090d15'); c.fillRect(0,0,w,h); c.fillStyle='#161b25'; c.fillRect(w*.15,h*.18,w*.7,h*.48); c.strokeStyle='#3c526b'; c.lineWidth=4; c.strokeRect(w*.15,h*.18,w*.7,h*.48);
      c.fillStyle='#06080d'; c.fillRect(w*.43,h*.43,w*.14,h*.23); c.strokeStyle='#5f4450'; c.lineWidth=5; c.strokeRect(w*.43,h*.43,w*.14,h*.23);
      const heads=[-.07,0,.07]; heads.forEach(dx=>{c.fillStyle='#0b0c0e';c.beginPath();c.arc(w*(.5+dx),h*.36,34,0,Math.PI*2);c.fill();c.fillStyle='#a44f58';c.beginPath();c.arc(w*(.49+dx),h*.35,3,0,Math.PI*2);c.fill();c.beginPath();c.arc(w*(.51+dx),h*.35,3,0,Math.PI*2);c.fill();});
    }
    drawClassroom(c,w,h,t,label='CLASS') {
      c.fillStyle=this.gradient(0,'#2a3840',h,'#12191d'); c.fillRect(0,0,w,h); c.fillStyle='#202b31'; c.fillRect(w*.1,h*.14,w*.8,h*.55);
      c.fillStyle='#0d2824'; c.fillRect(w*.28,h*.18,w*.44,h*.18); c.strokeStyle='#9a835e'; c.lineWidth=7; c.strokeRect(w*.28,h*.18,w*.44,h*.18);
      c.fillStyle='rgba(217,233,222,.38)'; c.font='700 24px sans-serif'; c.textAlign='center'; c.fillText(label,w*.5,h*.29);
      c.fillStyle='#4a3c2c'; for(let r=0;r<2;r++)for(let col=0;col<4;col++){const x=w*.19+col*w*.16,y=h*.49+r*h*.12;c.fillRect(x,y,w*.1,8);c.fillRect(x+8,y+8,5,h*.07);c.fillRect(x+w*.1-12,y+8,5,h*.07);}
      if(Math.sin(t*8)>.95){ c.fillStyle='rgba(235,242,200,.1)'; c.fillRect(w*.4,h*.04,w*.2,h*.05); }
    }
    drawStairs(c,w,h,t) {
      c.fillStyle=this.gradient(0,'#1f2a35',h,'#090d12'); c.fillRect(0,0,w,h); c.strokeStyle='#55616a'; c.lineWidth=3;
      for(let i=0;i<10;i++){const y=h*.77-i*h*.055, x=w*.24+i*w*.035, ww=w*.52-i*w*.07;c.fillStyle=i===5?'#090b0e':'#29343c';c.fillRect(x,y,ww,h*.04);c.strokeRect(x,y,ww,h*.04);} c.fillStyle='rgba(105,181,218,.08)';c.fillRect(w*.72,h*.12,w*.12,h*.3);
    }
    drawGym(c,w,h,t) {
      c.fillStyle=this.gradient(0,'#3a372e',h,'#171713'); c.fillRect(0,0,w,h); c.fillStyle='#6c5237'; c.fillRect(0,h*.62,w,h*.38); c.strokeStyle='rgba(230,210,175,.15)'; for(let i=0;i<12;i++){c.beginPath();c.moveTo(i*w/12,h*.62);c.lineTo(i*w/12,h);c.stroke();}
      c.fillStyle='#7c8790'; c.fillRect(w*.18,h*.18,w*.64,h*.27); c.fillStyle='#e5e8e8'; c.font='700 25px sans-serif'; c.textAlign='center'; c.fillText('체육수업 만족도 조사',w*.5,h*.28);
      c.fillStyle='#c45a4d'; c.beginPath();c.arc(w*.78,h*.58,31+Math.sin(t*2)*2,0,Math.PI*2);c.fill();
    }
    drawRooftop(c,w,h,t) {
      c.fillStyle=this.gradient(0,'#18344d',h*.62,'#0b1621'); c.fillRect(0,0,w,h); c.fillStyle='#20282d'; c.fillRect(0,h*.66,w,h*.34); c.strokeStyle='#7c8991'; c.lineWidth=4; c.beginPath(); c.moveTo(0,h*.6);c.lineTo(w,h*.6);c.stroke(); for(let i=0;i<16;i++){c.beginPath();c.moveTo(i*w/15,h*.6);c.lineTo(i*w/15,h*.78);c.stroke();}
      c.fillStyle='rgba(215,233,255,.6)'; for(let i=0;i<22;i++){const x=(i*83)%w,y=(i*47)%(h*.5);c.fillRect(x,y,1.5,1.5);} c.fillStyle='rgba(214,231,243,.8)'; c.beginPath();c.arc(w*.79,h*.18,44,0,Math.PI*2);c.fill();
      c.fillStyle='#0e1217'; c.beginPath();c.arc(w*.74,h*.49,16,0,Math.PI*2);c.fill(); c.fillRect(w*.73,h*.5,18,h*.11);
    }
    drawVoid(c,w,h,t) {
      c.fillStyle='#020304'; c.fillRect(0,0,w,h); const r=150+Math.sin(t*.9)*12; const g=c.createRadialGradient(w*.5,h*.5,0,w*.5,h*.5,r);g.addColorStop(0,'rgba(109,153,183,.12)');g.addColorStop(1,'transparent');c.fillStyle=g;c.beginPath();c.arc(w*.5,h*.5,r,0,Math.PI*2);c.fill();
      c.strokeStyle='rgba(220,235,245,.12)';c.lineWidth=5;c.strokeRect(w*.36,h*.22,w*.28,h*.48);
    }
  }

  class Game {
    constructor() {
      this.state = DEFAULT_STATE();
      this.renderer = new SceneRenderer(refs.sceneCanvas);
      this.audio = new AudioEngine(() => this.state.settings);
      this.lockCode = '';
      this.currentCombat = null;
      this.nameResolver = null;
      this.toastTimer = null;
      this.quizDeadline = 0;
      this.finalDeadline = 0;
      this.mashHandler = null;
      this.bind();
      this.buildKeypad();
      this.applySettings();
      this.updateContinueButton();
      if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
    }

    bind() {
      $('newGameBtn').addEventListener('click', () => { this.audio.click(); this.newGame(); });
      $('continueBtn').addEventListener('click', () => this.load());
      $('titleSettingsBtn').addEventListener('click', () => this.openSettings());
      $('creatorBackBtn').addEventListener('click', () => this.showScreen('title'));
      $('creatorStartBtn').addEventListener('click', () => this.startFromCreator());
      ['charNameInput','genderSelect','skinSelect','eyeSelect','noseSelect','mouthSelect','hairSelect','hairColorSelect','outfitSelect'].forEach(id => $(id).addEventListener('input', () => this.updateAvatarPreview()));
      $('menuBtn').addEventListener('click', () => this.openSettings());
      $('fullscreenBtn').addEventListener('click', () => this.toggleFullscreen());
      refs.viewToggleBtn.addEventListener('click', () => this.toggleView());
      $('settingsCloseBtn').addEventListener('click', () => this.closeModal(refs.settingsModal));
      $('saveBtn').addEventListener('click', () => this.save(true));
      $('returnTitleBtn').addEventListener('click', () => { this.save(false); this.closeAllModals(); this.closeDialogue(); this.showScreen('title'); });
      refs.soundToggle.addEventListener('change', () => { this.state.settings.sound=refs.soundToggle.checked; this.applySettings(); });
      refs.shakeToggle.addEventListener('change', () => { this.state.settings.shake=refs.shakeToggle.checked; this.applySettings(); });
      refs.scareSelect.addEventListener('change', () => { this.state.settings.scare=refs.scareSelect.value; this.applySettings(); });
      refs.motionToggle.addEventListener('change', () => { this.state.settings.reducedMotion=refs.motionToggle.checked; this.applySettings(); });
      $('lockClearBtn').addEventListener('click', () => { this.lockCode=''; this.updateLockDisplay(); });
      $('lockSubmitBtn').addEventListener('click', () => this.submitGateCode());
      refs.nameModalConfirm.addEventListener('click', () => this.resolveName());
      document.addEventListener('keydown', e => {
        if (e.key === '0' && refs.gameScreen.classList.contains('active')) this.toggleView();
        if (e.key === 'Escape') {
          if (!refs.settingsModal.classList.contains('hidden')) this.closeModal(refs.settingsModal);
          else this.closeDialogue();
        }
      });
    }

    buildKeypad() {
      refs.keypad.innerHTML='';
      ['1','2','3','4','5','6','7','8','9','','0','⌫'].forEach(v => {
        if (!v) { const d=document.createElement('div'); refs.keypad.appendChild(d); return; }
        const b=document.createElement('button'); b.textContent=v; b.type='button'; b.addEventListener('click',()=>{
          this.audio.click();
          if(v==='⌫') this.lockCode=this.lockCode.slice(0,-1); else if(this.lockCode.length<4) this.lockCode+=v;
          this.updateLockDisplay();
        }); refs.keypad.appendChild(b);
      });
      this.updateLockDisplay();
    }

    newGame() {
      const oldSettings = this.state.settings;
      const oldAchievements = this.state.achievements;
      this.state = DEFAULT_STATE();
      this.state.settings = { ...oldSettings };
      this.state.achievements = { ...oldAchievements };
      this.showScreen('creator');
      this.updateAvatarPreview();
    }

    showScreen(name) {
      [refs.titleScreen, refs.creatorScreen, refs.gameScreen].forEach(s=>s.classList.remove('active'));
      if(name==='title') { refs.titleScreen.classList.add('active'); refs.topBar.classList.add('hidden'); refs.hud.classList.add('hidden'); this.renderer.set('gate'); this.audio.stopAmbient(); this.updateContinueButton(); }
      if(name==='creator') { refs.creatorScreen.classList.add('active'); refs.topBar.classList.add('hidden'); refs.hud.classList.add('hidden'); this.audio.stopAmbient(); }
      if(name==='game') { refs.gameScreen.classList.add('active'); refs.topBar.classList.remove('hidden'); refs.hud.classList.remove('hidden'); this.audio.startAmbient(); }
    }

    updateAvatarPreview() {
      const a=refs.avatarPreview;
      const gender=$('genderSelect').value, skin=$('skinSelect').value, eye=$('eyeSelect').value, nose=$('noseSelect').value, mouth=$('mouthSelect').value, hair=$('hairSelect').value, hc=$('hairColorSelect').value, outfit=$('outfitSelect').value;
      a.dataset.gender=gender; a.dataset.hair=hair; a.dataset.mouth=mouth; a.dataset.nose=nose;
      a.style.setProperty('--skin',SKIN[skin]); a.style.setProperty('--skin-shadow',this.shade(SKIN[skin],-.12)); a.style.setProperty('--hair',HAIR[hc]); a.style.setProperty('--hair-hi',this.shade(HAIR[hc],.16)); a.style.setProperty('--eye',EYES[eye]); a.style.setProperty('--cloth',CLOTH[outfit]);
      refs.creatorPreviewName.textContent=$('charNameInput').value.trim()||'주인공';
    }

    shade(hex, p) {
      const n=parseInt(hex.slice(1),16), r=n>>16, g=n>>8&255, b=n&255, t=p<0?0:255, P=Math.abs(p);
      const f=x=>Math.round((t-x)*P+x); return '#'+((1<<24)+(f(r)<<16)+(f(g)<<8)+f(b)).toString(16).slice(1);
    }

    startFromCreator() {
      this.state.name=$('charNameInput').value.trim()||'지우'; this.state.gender=$('genderSelect').value;
      this.state.appearance={skin:$('skinSelect').value, eyes:$('eyeSelect').value, nose:$('noseSelect').value, mouth:$('mouthSelect').value, hair:$('hairSelect').value, hairColor:$('hairColorSelect').value, outfit:$('outfitSelect').value};
      this.state.scene='gate'; this.state.checkpoint='gate'; this.showScreen('game'); this.applyAvatarToHud(); this.updateHUD(); this.enterGate();
    }

    applyAvatarToHud() {
      refs.hudName.textContent=this.state.name;
      refs.miniAvatar.style.setProperty('--mini-hair',HAIR[this.state.appearance.hairColor]||HAIR.darkbrown);
      refs.miniAvatar.style.setProperty('--mini-skin',SKIN[this.state.appearance.skin]||SKIN.light);
    }

    setScene(scene, area, objective) {
      this.state.scene=scene; this.renderer.set(scene); refs.areaLabel.textContent=area; refs.objectiveLabel.textContent=objective; this.clearHotspots();
    }

    addHotspot({x,y,title,sub='',action,kind=''}) {
      const b=document.createElement('button'); b.className='hotspot'+(kind?` hotspot--${kind}`:''); b.style.left=`${x}%`; b.style.top=`${y}%`; b.innerHTML=`<strong>${title}</strong>${sub?`<small>${sub}</small>`:''}`; b.addEventListener('click',()=>{this.audio.click();action();}); refs.interactionLayer.appendChild(b); return b;
    }
    clearHotspots() { refs.interactionLayer.innerHTML=''; }

    enterGate() {
      this.setScene('gate','폐교 정문','교문 자물쇠를 풀고 안으로 들어가세요.');
      this.addHotspot({x:50,y:61,title:'🔒 교문 자물쇠',sub:'4자리 암호 입력',action:()=>this.openGateLock(),kind:'gold'});
      this.save(false);
    }

    openGateLock() { this.lockCode=''; this.updateLockDisplay(); this.openModal(refs.lockModal); }
    updateLockDisplay() { refs.lockDisplay.textContent=(this.lockCode+'••••').slice(0,4).split('').join(' '); }
    submitGateCode() {
      if(this.lockCode==='4444') { this.audio.lock(); this.closeModal(refs.lockModal); this.flash(); this.toast('철컥… 교문이 열렸다.'); setTimeout(()=>this.enterLobby(),500); }
      else { this.audio.danger(); this.toast('암호가 틀렸다.'); this.lockCode=''; this.updateLockDisplay(); }
    }

    enterLobby() {
      this.setScene('lobby','폐교 중앙 현관','세 개의 입구 중 난이도를 선택하세요.');
      this.addHotspot({x:25,y:55,title:'급식실',sub:'쉬움 · HP 1000 · 목숨 5',action:()=>this.beginEasy()});
      this.addHotspot({x:50,y:55,title:'본관',sub:'일반 · HP 500',action:()=>this.beginNormal()});
      this.addHotspot({x:75,y:55,title:'신관',sub:'챌린저 · HP 100',action:()=>this.beginChallenge(),kind:'danger'});
    }

    setDifficulty(diff) {
      this.state.difficulty=diff; this.state.inventory=[];
      if(diff==='easy') { Object.assign(this.state,{maxHp:1000,hp:1000,lives:5,attack:70,weapon:'퇴마봉',armor:100,keys:1,mood:'경계'}); this.addItems(['손전등','갑옷','방패','퇴마봉','쉬움 열쇠']); }
      if(diff==='normal') { Object.assign(this.state,{maxHp:500,hp:500,lives:3,attack:45,weapon:'없음',armor:0,keys:0,mood:'긴장'}); this.addItems(['제작 재료']); }
      if(diff==='challenge') { Object.assign(this.state,{maxHp:100,hp:100,lives:1,attack:55,weapon:'없음',armor:0,keys:0,mood:'초긴장'}); this.addItems(['손전등']); }
      this.updateHUD();
    }

    beginEasy() {
      this.setDifficulty('easy'); this.state.checkpoint='easyHall'; this.state.easy={cafeteriaClosed:false,toiletClosed:false,toiletGhostDead:false,exitSpawned:false};
      this.enterEasyHall(); this.toast('쉬움 지급품: 손전등 · 갑옷 · 무기 · 방패 · 열쇠');
    }
    enterEasyHall() {
      this.setScene('easyHall','급식실 구역 · 쉬움','급식실과 화장실을 조사하고 탈출구를 찾으세요.');
      this.addHotspot({x:70,y:46,title:'오른쪽 · 급식실',sub:this.state.easy.cafeteriaClosed?'잠겨 있다':'영양사실 쪽',action:()=>this.enterCafeteria()});
      this.addHotspot({x:29,y:47,title:'왼쪽 · 화장실',sub:this.state.easy.toiletClosed?'문이 잠겼다':'희미한 물소리',action:()=>this.enterEasyToilet()});
      this.addHotspot({x:16,y:35,title:'왼쪽 뒤 3번째 창문',sub:'유난히 검은 유리',action:()=>this.hiddenWatcher(),kind:'danger'});
      if(this.state.easy.exitSpawned) this.addHotspot({x:50,y:34,title:'새로 생긴 문',sub:'낡은 열쇠가 반응한다',action:()=>this.easyExit(),kind:'gold'});
    }
    enterCafeteria() {
      if(this.state.easy.cafeteriaClosed) { this.toast(this.state.keys>0?'열쇠가 구멍에 맞지 않아.':'잠겨있어.'); return; }
      this.setScene('cafeteria','급식실','입구에 얼굴 없는 영양사 귀신이 서 있다.'); this.jumpScare();
      this.say('얼굴 없는 영양사 귀신','무표정','얼굴이 있어야 할 자리가 매끈하다. 식판 끄는 소리만 천천히 가까워진다.',[
        this.choice('⚔ 싸우기',()=>this.startCombat({name:'영양사 귀신',hp:99999,attack:99999,unbeatable:true,onDefeat:()=>{}}),true),
        this.choice('🏃 도망치기',()=>this.resolveCafeteriaNonFight('도망쳤다. 뒤에서 식판 끌리는 소리가 멎었다.')),
        this.choice('🫥 숨기',()=>this.resolveCafeteriaNonFight('급식 운반카트 뒤에 숨었다. 잠시 뒤 귀신이 사라졌다.')),
        this.choice('🕯 과거를 보기',()=>this.cafeteriaPast())
      ],'ghost');
    }
    cafeteriaPast() {
      this.say('영양사 선생님의 기억','슬픔','마지막 급식 날, 정전 속에서도 아이들의 식사를 끝까지 챙기던 선생님은 사고가 난 조리실에 홀로 남았다. 아이들이 배고프지 않았으면 좋겠다는 마음만 남아 학교를 떠나지 못했다.',[
        this.choice('“선생님, 이제 쉬셔도 돼요.”',()=>this.resolveCafeteriaNonFight('희미한 종소리와 함께 영양사 귀신이 고개를 숙였다.'))
      ],'sad');
    }
    resolveCafeteriaNonFight(msg) { this.state.easy.cafeteriaClosed=true; this.closeDialogue(); this.toast(msg); this.enterEasyHall(); }
    enterEasyToilet() {
      if(this.state.easy.toiletClosed && !this.state.easy.toiletGhostDead) { this.toast('문이 잠겨 다시 들어갈 수 없다.'); return; }
      if(this.state.easy.toiletGhostDead) { this.toast('세면대는 비어 있다.'); return; }
      this.setScene('toilet','급식실 옆 화장실','변기 쪽에서 물방울 소리가 들린다.'); this.jumpScare();
      this.say('화장실 처녀귀신','분노','변기 안에서 창백한 손이 확 튀어나왔다. 이번에는 도망치면 다시 들어올 수 없을 것 같다.',[
        this.choice('⚔ 싸운다',()=>this.startCombat({name:'화장실 귀신',hp:85,attack:50,onDefeat:()=>{this.state.easy.toiletGhostDead=true;this.state.keys++;this.addItems(['세면대 열쇠']);this.state.easy.exitSpawned=true;this.toast('세면대에서 열쇠를 얻었다. 복도에 없던 문이 생겼다.');this.enterEasyHall();}})),
        this.choice('🏃 도망친다',()=>{this.state.easy.toiletClosed=true;this.closeDialogue();this.toast('쾅! 화장실 문이 잠겼다.');this.enterEasyHall();}),
        this.choice('🫥 숨는다',()=>{this.state.easy.toiletClosed=true;this.closeDialogue();this.toast('숨는 사이 출구가 잠겼다. 다시 들어갈 수 없다.');this.enterEasyHall();})
      ],'ghost');
    }
    easyExit() {
      if(!this.state.easy.toiletGhostDead || this.state.keys<1) { this.toast('이 문에 맞는 열쇠가 없다.'); return; }
      this.state.keys--; this.removeItem('세면대 열쇠'); this.updateHUD(); this.completeDifficulty('쉬움 난이도 클리어!','normal');
    }
    hiddenWatcher() {
      this.setScene('void','???','거울을 바라본다.'); this.audio.danger(); this.flash();
      this.say(this.state.name,'소름','캄캄한 공간. 거울 속의 내가 천천히 웃는다. 그런데… 내 뒤에 있던 것이 아니라, 거울 속 “나” 자체가 감시자다.',[
        this.choice('거울에서 눈을 떼지 않는다',()=>this.watcherEnding()),
        this.choice('뒤로 물러난다',()=>{this.closeDialogue();this.enterEasyHall();})
      ],'watcher');
    }
    watcherEnding() {
      this.state.achievements.watcherBadge=true; this.save(false); this.showEnding({kicker:'HIDDEN ENDING',title:'감시자',text:'이 학교를 망하게 하고 모든 사람을 귀신으로 만든 존재는 처음부터 “당신”의 얼굴을 하고 있었다. 거울 속 캐릭터가 소름 끼치게 미소 짓는다.',reward:'🏅 감시자 배지 획득',actions:[['저장하고 로비로',()=>this.returnTitle()],['다시 도전',()=>this.beginEasy()]]});
    }

    beginNormal() {
      this.setDifficulty('normal'); this.state.checkpoint='normalEntry'; this.state.normal={...DEFAULT_STATE().normal};
      this.askName('안내견 이름 정하기','갈색 말티푸 안내견의 이름을 정해 주세요.','몽이').then(name=>{this.state.normal.dogName=name;this.enterNormalEntry();});
    }
    enterNormalEntry() {
      this.setScene('normalEntry','본관 입구 · 일반','화장실에서 열쇠를 찾고, 아이템을 제작한 뒤 청소부 귀신을 통과하세요.');
      this.addHotspot({x:22,y:49,title:'입구 옆 화장실',sub:this.state.normal.restroomKey?'이미 조사함':'변기 안쪽을 조사',action:()=>this.normalRestroom()});
      this.addHotspot({x:50,y:44,title:'간이 제작대',sub:this.state.normal.crafted?'제작 완료':'재료로 장비 제작',action:()=>this.normalCraft()});
      this.addHotspot({x:77,y:49,title:'청소부 아저씨 귀신',sub:'본관문을 지키고 있다',action:()=>this.janitor(),kind:'danger'});
      this.addHintHotspot();
    }
    addHintHotspot() {
      if(!this.state.normal.dogName) return;
      this.addHotspot({x:13,y:81,title:`🐕 ${this.state.normal.dogName}`,sub:'힌트 듣기',action:()=>this.dogHint()});
    }
    dogHint() {
      let hint='냄새를 맡아보니 화장실 변기 쪽에서 쇠 냄새가 나!';
      if(this.state.normal.restroomKey&&!this.state.normal.crafted) hint='열쇠는 찾았어. 이제 제작대에서 장비를 만들자!';
      if(this.state.normal.restroomKey&&this.state.normal.crafted) hint='청소부 아저씨에게 열쇠를 주면 안으로 들어갈 수 있을 것 같아.';
      if(this.state.scene==='normalHall') hint=this.state.normal.principalKills<3?'교장실은 셋을 한꺼번에 상대하지 말고 한 명씩 유인하자.':'과학실로 가자. 세 부탁을 해결하면 뭔가 합쳐질 것 같아.';
      this.say(this.state.normal.dogName,'기대',`“${hint}”`,[this.choice('알겠어!',()=>this.closeDialogue())],'dog');
    }
    normalRestroom() {
      if(this.state.normal.restroomKey) { this.toast('변기 안은 비어 있다.'); return; }
      this.renderer.set('toilet'); this.jumpScare(false); this.say('본관 화장실','긴장','변기 뒤쪽 물탱크 안에서 녹슨 열쇠가 손에 잡힌다.',[
        this.choice('열쇠를 챙긴다',()=>{this.state.normal.restroomKey=true;this.state.keys++;this.addItems(['본관 입구 열쇠']);this.closeDialogue();this.enterNormalEntry();})
      ],'neutral');
    }
    normalCraft() {
      if(this.state.normal.crafted) { this.toast('장비는 이미 제작했다.'); return; }
      this.say('제작대','집중','주어진 재료를 조합할 수 있다. 일반 난이도에서는 장비를 직접 만들어야 한다.',[
        this.choice('못 박힌 빗자루 + 간이 갑옷 제작',()=>{this.state.normal.crafted=true;this.state.weapon='못 박힌 빗자루';this.state.attack=65;this.state.armor=80;this.addItems(['못 박힌 빗자루','간이 갑옷']);this.removeItem('제작 재료');this.updateHUD();this.closeDialogue();this.enterNormalEntry();})
      ],'neutral');
    }
    janitor() {
      this.say('청소부 아저씨 귀신','무표정','“열쇠 없는 학생은 본관에 못 들어가.” 낡은 대걸레가 바닥을 긁는다.',[
        this.choice('🔑 열쇠를 건넨다',()=>{if(!this.state.normal.restroomKey||this.state.keys<1){this.toast('건넬 열쇠가 없다.');return;}this.state.keys--;this.removeItem('본관 입구 열쇠');this.closeDialogue();this.enterNormalHall();}),
        this.choice('뒤로 간다',()=>this.closeDialogue())
      ],'ghost');
    }
    enterNormalHall() {
      this.setScene('normalHall','본관 1층 복도','교장실에서 과학실 열쇠를 얻고 과학실의 세 퀘스트를 해결하세요.');
      this.addHotspot({x:30,y:46,title:'왼쪽 · 과학실',sub:this.state.normal.principalKills<3?'잠겨 있음':'열쇠 사용 가능',action:()=>this.enterScience()});
      this.addHotspot({x:70,y:46,title:'오른쪽 · 교장실',sub:`귀신 ${this.state.normal.principalKills}/3 처리`,action:()=>this.enterPrincipal(),kind:'danger'});
      this.addHotspot({x:50,y:28,title:'맨 뒤 · 잠긴 출구',sub:this.state.normal.goldenKey?'금빛 열쇠가 빛난다':'강한 봉인',action:()=>this.normalExit(),kind:'gold'});
      this.addHintHotspot();
      if(this.state.normal.friendName) this.addHotspot({x:87,y:81,title:`👥 ${this.state.normal.friendName}`,sub:'외모/이름 확인',action:()=>this.friendMirror()});
    }
    enterPrincipal() {
      this.renderer.set('principal');
      if(this.state.normal.principalKills>=3){this.toast('교장실은 조용하다. 과학실 열쇠는 이미 얻었다.');return;}
      const ghosts=['반장 학생 귀신','교감 선생님 귀신','교장 선생님 귀신']; const target=ghosts[this.state.normal.principalKills];
      this.say('교장실','위험',`세 귀신이 한꺼번에 서 있다. ${target}만 복도 쪽으로 유인하면 일대일로 싸울 수 있다.`,[
        this.choice(`${target}만 유인한다`,()=>this.startCombat({name:target,hp:120+this.state.normal.principalKills*40,attack:50,onDefeat:()=>{this.state.normal.principalKills++;if(this.state.normal.principalKills===3){this.state.keys++;this.addItems(['과학실 열쇠']);this.toast('세 귀신을 모두 물리쳤다. 과학실 열쇠 획득!');}else this.toast(`${target}을 물리쳤다. 나머지는 ${3-this.state.normal.principalKills}명.`);this.enterNormalHall();}})),
        this.choice('셋 모두에게 달려든다',()=>{this.closeDialogue();this.takeDamage(250,'세 귀신에게 포위당했다.');}),
        this.choice('복도로 돌아간다',()=>{this.closeDialogue();this.enterNormalHall();})
      ],'ghost');
    }
    enterScience() {
      if(this.state.normal.principalKills<3){this.toast('과학실 문이 잠겨 있다.');return;}
      this.setScene('science','과학실','개구리, 더러운 책상, 해골모형의 문제를 해결하세요.');
      if(!this.state.normal.frogDone) this.addHotspot({x:26,y:58,title:'해부된 개구리 귀신',sub:'무언가를 찾고 있다',action:()=>this.frogQuest()});
      if(!this.state.normal.deskDone) this.addHotspot({x:50,y:60,title:'더러운 실험대',sub:'청소 퀘스트',action:()=>this.deskQuest()});
      if(!this.state.normal.skeletonDone) this.addHotspot({x:76,y:55,title:'해골모형 귀신',sub:'위험한 선택',action:()=>this.skeletonQuest(),kind:'danger'});
      if(this.state.normal.scienceFragments>=3) this.assembleGoldenKey();
    }
    frogQuest() {
      this.say('해부된 개구리 귀신','슬픔','“내가… 어디에 흩어졌는지 모르겠어.” 유리병과 표본함을 가리킨다.',[
        this.choice('내장을 찾아 원래 자리에 돌려준다',()=>{this.state.normal.frogDone=true;this.state.normal.scienceFragments++;this.addItems(['열쇠 조각 A']);this.closeDialogue();this.toast('“고마워…” 개구리 귀신이 사라지며 조각을 남겼다.');this.enterScience();}),
        this.choice('그냥 지나간다',()=>this.closeDialogue())
      ],'sad');
    }
    deskQuest() {
      this.say('퀘스트','집중','더러운 책상 청소하기. 쏟아진 시약, 유리 조각, 먼지를 순서대로 정리한다.',[
        this.choice('끝까지 깨끗하게 정리한다',()=>{this.state.normal.deskDone=true;this.state.normal.scienceFragments++;this.addItems(['물약 결정 조각']);this.closeDialogue();this.toast('과학선생 귀신이 기특하다며 물약 2개를 남겼다. 섞자 열쇠조각 모양으로 굳었다.');this.enterScience();})
      ],'neutral');
    }
    skeletonQuest() {
      this.say('해골모형 귀신','의심','딱딱 소리를 내며 턱을 움직인다. 무엇을 해줄까?',[
        this.choice('상아 점토로 살을 만들어준다',()=>{this.say('해골모형 귀신','분노','“날 놀리는 거냐?” 해골의 눈이 붉게 타오르며 각성했다.',[this.choice('…',()=>this.instantKill('각성한 해골귀신에게 당했다.'))],'ghost');},true),
        this.choice('내 얼굴과 옷을 해골처럼 칠한다',()=>{this.state.normal.skeletonDone=true;this.state.normal.scienceFragments++;this.addItems(['열쇠 조각 C']);this.closeDialogue();this.toast('“동족이었군.” 해골이 조각을 건넸다.');this.enterScience();})
      ],'ghost');
    }
    assembleGoldenKey() {
      if(this.state.normal.goldenKey) return;
      this.state.normal.goldenKey=true; this.state.weapon='금빛 열쇠'; this.state.keys=1; this.addItems(['금빛 열쇠']); this.flash(); this.audio.success(); this.updateHUD();
      this.say('알 수 없는 힘','놀람','세 조각이 공중에서 맞물리며 금빛 열쇠로 변했다. 동시에 보이지 않는 힘이 캐릭터를 과학실 밖으로 밀어낸다.',[
        this.choice('복도로 밀려난다',()=>{this.closeDialogue();this.kongKongEncounter();})
      ],'neutral');
    }
    kongKongEncounter() {
      this.renderer.set('normalHall'); this.say('콩콩귀신','슬픔','복도 끝에서 “콩… 콩…” 소리가 난다. 아이가 조심스럽게 묻는다. “내 얘기… 들어줄래?”',[
        this.choice('“응. 천천히 말해도 돼.”',()=>this.kongKongStory()),
        this.choice('“지금 바빠. 비켜.”',()=>{this.closeDialogue();this.toast('콩콩 소리가 점점 멀어졌다.');this.enterNormalHall();})
      ],'sad');
    }
    kongKongStory() {
      this.say('콩콩귀신','울음','아이는 혼자 남겨졌던 날과 아무도 자신의 말을 믿어주지 않았던 일을 털어놓는다. “그때 내가 잘못한 걸까?”',[
        this.choice('“네 잘못이 아니야. 나는 네 말을 믿어.”',()=>this.befriendKongKong()),
        this.choice('“그땐 네가 더 조심했어야지.”',()=>{this.closeDialogue();this.toast('아이의 표정이 굳었다. 친구가 되지 못했다.');this.enterNormalHall();})
      ],'sad');
    }
    async befriendKongKong() {
      this.state.normal.friendGender=this.state.gender==='male'?'female':'male';
      const defaultName=this.state.gender==='male'?'서아':'민호';
      const name=await this.askName('새로운 친구','학생의 모습으로 돌아온 콩콩귀신에게 이름을 정해 주세요.',defaultName);
      this.state.normal.friendName=name; this.state.normal.friendAppearance=Math.floor(Math.random()*4); this.closeDialogue(); this.audio.success(); this.toast(`${name}이(가) 일행이 되었다. 챌린저 모드까지 함께한다.`); this.enterNormalHall();
    }
    friendMirror() {
      this.say(this.state.normal.friendName,'미소','복도 거울 앞에서 잠시 옷매무새를 고친다. 외모를 바꿀 수 있다.',[
        this.choice('내 머리 스타일 바꾸기',()=>{const h=['soft','layered','short','wave'];const i=(h.indexOf(this.state.appearance.hair)+1)%h.length;this.state.appearance.hair=h[i];this.toast('주인공 헤어스타일을 변경했다.');this.closeDialogue();}),
        this.choice('친구 스타일 바꾸기',()=>{this.state.normal.friendAppearance=(this.state.normal.friendAppearance+1)%4;this.toast(`${this.state.normal.friendName}의 스타일을 변경했다.`);this.closeDialogue();}),
        this.choice('그대로 두기',()=>this.closeDialogue())
      ],'friend');
    }
    normalExit() {
      if(!this.state.normal.goldenKey){this.toast('금빛 열쇠가 필요하다.');return;}
      this.completeDifficulty('일반 난이도 클리어!','challenge');
    }

    beginChallenge() {
      this.setDifficulty('challenge'); this.state.checkpoint='challengeEntry'; const keepFriend=this.state.normal.friendName; const keepFriendGender=this.state.normal.friendGender; const keepFriendAppearance=this.state.normal.friendAppearance; this.state.challenge={...DEFAULT_STATE().challenge};
      if(!keepFriend){this.state.normal.friendName=this.state.gender==='male'?'서아':'민호';this.state.normal.friendGender=this.state.gender==='male'?'female':'male';}
      else {this.state.normal.friendName=keepFriend;this.state.normal.friendGender=keepFriendGender;this.state.normal.friendAppearance=keepFriendAppearance;}
      this.enterChallengeEntry();
    }
    enterChallengeEntry() {
      this.setScene('challengeEntry','신관 입구 · 챌린저','화장실에서 열쇠를 찾고 케르베로스의 시험을 통과하세요.');
      this.addHotspot({x:24,y:54,title:'신관 옆 화장실',sub:this.state.challenge.restroomKey?'이미 열쇠 획득':'변기 안을 조사',action:()=>this.challengeRestroom()});
      this.addHotspot({x:51,y:46,title:'케르베로스',sub:this.state.challenge.cerberusDone?'길을 비켜줌':'세 머리의 1분 퀴즈',action:()=>this.cerberusIntro(),kind:'danger'});
      this.addHotspot({x:80,y:76,title:'손전등 보급함',sub:'죽으면 잃기 쉬워 많이 비치되어 있다',action:()=>{this.addItems(['손전등']);this.toast('손전등을 하나 챙겼다.');}});
    }
    challengeRestroom() {
      if(this.state.challenge.restroomKey){this.toast('이미 열쇠를 챙겼다.');return;}
      this.renderer.set('toilet'); this.say('신관 화장실','긴장','변기 안쪽 깊은 곳에서 차가운 열쇠가 손끝에 걸린다.',[
        this.choice('꺼낸다',()=>{this.state.challenge.restroomKey=true;this.state.keys=1;this.addItems(['신관 열쇠']);this.closeDialogue();this.enterChallengeEntry();})
      ],'neutral');
    }
    cerberusIntro() {
      if(this.state.challenge.cerberusDone){this.challengeFloor1();return;}
      this.say('케르베로스','위협','세 머리가 동시에 으르렁거린다. “1분 안에 세 문제를 모두 맞히면 길을 비켜주겠다.”',[
        this.choice('퀴즈로 통과한다',()=>{this.quizDeadline=Date.now()+60000;this.cerberusQ1();}),
        this.choice('싸운다',()=>{if(this.state.weapon==='전설의 검'){this.state.challenge.cerberusDone=true;this.closeDialogue();this.challengeFloor1();}else this.startCombat({name:'케르베로스',hp:750,attack:10,onDefeat:()=>{this.state.challenge.cerberusDone=true;this.challengeFloor1();}});})
      ],'ghost');
    }
    quizAlive(){if(Date.now()>this.quizDeadline){this.toast('1분이 지났다! 퀴즈가 초기화된다.');this.closeDialogue();this.enterChallengeEntry();return false;}return true;}
    cerberusQ1(){if(!this.quizAlive())return;this.say('케르베로스 · 첫째 머리','퀴즈','“세상에서 가장 시끄러운 물놀이는?”',[
      this.choice('사물놀이',()=>this.cerberusQ2()),this.choice('물총놀이',()=>this.quizWrong()),this.choice('수영대회',()=>this.quizWrong())
    ],'ghost');}
    cerberusQ2(){if(!this.quizAlive())return;this.say('케르베로스 · 둘째 머리','퀴즈','“아침에는 4발, 점심에는 2발, 저녁에는 3발로 걷는 동물은?”',[
      this.choice('사람',()=>this.cerberusQ3()),this.choice('개',()=>this.quizWrong()),this.choice('고양이',()=>this.quizWrong())
    ],'ghost');}
    cerberusQ3(){if(!this.quizAlive())return;this.say('케르베로스 · 셋째 머리','퀴즈','“먹을 수 있는 제비는?”',[
      this.choice('수제비',()=>{if(!this.quizAlive())return;this.state.challenge.cerberusDone=true;this.closeDialogue();this.audio.success();this.toast('세 머리가 동시에 고개를 끄덕이며 길을 비켰다.');this.challengeFloor1();}),this.choice('제비꽃',()=>this.quizWrong()),this.choice('참제비',()=>this.quizWrong())
    ],'ghost');}
    quizWrong(){this.audio.danger();this.toast('틀렸다! 처음부터 다시.');this.closeDialogue();setTimeout(()=>this.cerberusIntro(),500);}
    challengeFloor1() {
      this.setScene('english','신관 1층','영어교실에서 파란 조각을 얻고 계단으로 올라가세요.');
      this.addHotspot({x:35,y:51,title:'영어교실',sub:this.state.challenge.englishDone?'수업 완료':'영어 선생님 귀신',action:()=>this.englishRoom()});
      this.addHotspot({x:72,y:54,title:'2층 계단',sub:'중간 계단이 부서져 있다',action:()=>this.brokenStairs()});
    }
    englishRoom() {
      this.renderer.set('english');
      if(!this.state.challenge.englishDone){this.say('영어 선생님 귀신','차분','“Good evening. How are you feeling right now?”',[
        this.choice('I am scared, but I will keep going.',()=>{this.state.challenge.englishDone=true;this.state.challenge.blue++;this.addItems(['파란 조각 1']);this.closeDialogue();this.toast('영어 선생님이 파란 조각을 건넸다.');this.maybeEnglishStudent();}),
        this.choice('Give me the piece.',()=>{this.takeDamage(10,'무례한 대답에 교실 공기가 얼어붙었다.');})
      ],'teacher');} else this.maybeEnglishStudent();
    }
    maybeEnglishStudent() {
      if(Math.random()<.5){this.jumpScare(false);this.say('영어수업 학생귀신','집착','학생귀신이 파란 조각을 노리고 나타났다. 싸우면 조각을 빼앗길 수 있다.',[
        this.choice('숨는다',()=>{this.closeDialogue();this.toast('책상 아래에서 무사히 지나갔다.');this.challengeFloor1();}),
        this.choice('도망친다',()=>{this.closeDialogue();this.toast('조각을 지키며 교실 밖으로 빠져나왔다.');this.challengeFloor1();}),
        this.choice('싸운다',()=>{if(this.state.challenge.blue>0){this.state.challenge.blue--;this.removeItem('파란 조각 1');this.toast('싸우는 사이 파란 조각을 빼앗겼다!');}this.startCombat({name:'영어수업 학생귀신',hp:120,attack:10,onDefeat:()=>this.challengeFloor1()});},true)
      ],'ghost');} else {this.toast('이번에는 학생귀신이 나타나지 않았다.');this.challengeFloor1();}
    }
    brokenStairs() {
      this.setScene('stairs','신관 계단','높은 점프력 때문에 너무 멀리 뛰지 않도록 조심하세요.');
      this.say(this.state.normal.friendName,'경계','“중간 계단이 부서졌어. 힘껏 말고, 짧게 뛰어!”',[
        this.choice('짧게 점프한다',()=>{this.closeDialogue();this.toast('안전하게 2층에 착지했다.');this.challengeFloor2();}),
        this.choice('최대한 높이 점프한다',()=>{this.closeDialogue();this.takeDamage(30,'천장에 부딪혀 떨어졌다.');this.challengeFloor1();})
      ],'friend');
    }
    challengeFloor2() {
      this.setScene('math','신관 2층','수학선생 귀신을 친구와 협동해 처치하세요.');
      this.addHotspot({x:48,y:52,title:'수학교실',sub:this.state.challenge.mathDone?'조용하다':'매우 위험한 귀신',action:()=>this.mathRoom(),kind:'danger'});
      if(this.state.challenge.mathDone) this.addHotspot({x:78,y:38,title:'3층 계단',sub:'체육교실로 이동',action:()=>this.challengeFloor3()});
    }
    mathRoom() {
      if(this.state.challenge.mathDone){this.toast('칠판에는 분필 자국만 남아 있다.');return;}
      this.state.weapon='전설의 검';this.state.attack=120;this.addItems(['전설의 검']);this.updateHUD();
      this.say(this.state.normal.friendName,'결의',`“${this.state.name}, 이걸 받아!” ${this.state.normal.friendName}이(가) 전설의 검을 건넨다. 수학선생 귀신이 이미 달려오고 있다.`,[
        this.choice('친구와 협동해 싸운다',()=>this.startCombat({name:'수학선생 귀신',hp:360,attack:10,smart:true,onDefeat:()=>{this.state.challenge.mathDone=true;this.mathTrap();}}))
      ],'friend');
    }
    mathTrap() {
      this.renderer.set('math'); this.say('감금되어 있던 학생귀신','기쁨','“구해줘서 고마워! 여기 파란 조각!” 학생이 파란색 물체를 내민다. 그런데 심지가 살짝 보인다.',[
        this.choice('학생이 주는 파란 조각을 받는다',()=>this.instantKill('파란 물체는 다이너마이트였다.'),true),
        this.choice('칠판을 자세히 조사한다',()=>{this.state.challenge.blue++;this.addItems(['파란 조각 2']);this.closeDialogue();this.toast('칠판 틈에서 진짜 파란 조각을 찾았다.');this.challengeFloor2();})
      ],'ghost');
    }
    challengeFloor3() {
      this.setScene('pe','신관 3층','체육수업 설문을 완료하고 올바른 모양의 조각을 얻으세요.');
      this.addHotspot({x:40,y:51,title:'체육교실',sub:this.state.challenge.peDone?'조각 획득 완료':'수상한 만족도 조사',action:()=>this.peSurvey()});
      this.addHotspot({x:76,y:36,title:'옥상 계단',sub:this.state.challenge.peDone?'올라갈 수 있다':'체육교실부터 조사',action:()=>{if(!this.state.challenge.peDone)this.toast('먼저 체육교실을 조사하자.');else this.rooftop();}});
    }
    peSurvey(step=0) {
      if(this.state.challenge.peDone){this.toast('설문은 이미 제출했다.');return;}
      this.renderer.set('pe'); const qs=['오늘 체육수업은 즐거웠나요?','활동량은 적절했나요?','선생님의 설명은 이해하기 쉬웠나요?'];
      if(step<qs.length){this.say('체육수업 설문','평가',qs[step],[this.choice('매우 좋았음',()=>this.peSurvey(step+1)),this.choice('좋았음',()=>{this.toast('설문지가 처음으로 돌아갔다.');this.peSurvey(0);}),this.choice('보통',()=>{this.toast('설문지가 처음으로 돌아갔다.');this.peSurvey(0);})],'neutral');return;}
      this.say('보상함','선택','설문 완료. 보상 조각을 하나 선택하세요.',[
        this.choice('⭕ 동그라미 조각',()=>this.rpsIntro()),
        this.choice('🔺 세모 조각',()=>{this.closeDialogue();this.toast('복도가 끝없이 반복된다… 미궁에 빠졌다!');setTimeout(()=>this.challengeFloor3(),1100);},true)
      ],'neutral');
    }
    rpsIntro() {
      this.say('욕심쟁이 학생귀신','도전','“그 동그라미 내가 가져갈 거야! 안 내면 진다, 가위바위보!” 체육선생 귀신의 목소리가 끝날 때까지 선택해야 한다.',[
        this.choice('✊ 주먹',()=>this.resolveRps('rock')),
        this.choice('✌ 가위',()=>this.resolveRps('scissors')),
        this.choice('🖐 보',()=>this.resolveRps('paper'))
      ],'ghost');
    }
    resolveRps(player) {
      // intentionally not surfaced in UI; this ghost has a fixed behavioral pattern.
      const ghost=['sc','is','sors'].join('');
      const win=(player==='rock'&&ghost==='scissors')||(player==='scissors'&&ghost==='paper')||(player==='paper'&&ghost==='rock');
      if(win){this.state.challenge.peDone=true;this.state.challenge.green++;this.addItems(['초록 동그라미 조각']);this.closeDialogue();this.audio.success();this.toast('가위바위보 승리! 초록 동그라미 조각 획득.');this.challengeFloor3();}
      else {this.closeDialogue();this.audio.danger();this.toast('졌다. 체육선생 귀신의 그림자가 덮친다.');setTimeout(()=>this.instantKill('가위바위보에서 패배해 체육선생 귀신에게 당했다.'),700);}
    }
    rooftop() {
      this.setScene('rooftop','신관 옥상','난간에 선 학생에게 조심스럽게 말을 거세요.');
      if(this.state.challenge.rooftopDone){this.finalFrame();return;}
      this.say('난간의 학생','절망','“아무도 나를 기억하지 못할 거야.” 학생은 난간 너머만 바라본다.',[
        this.choice('“나는 지금 네 이야기를 듣고 있어. 같이 내려가자.”',()=>{this.state.challenge.rooftopDone=true;this.state.challenge.blue++;this.addItems(['파란 조각 3']);this.closeDialogue();this.toast('학생이 고맙다며 파란 조각을 건넸다.');this.finalFrame();}),
        this.choice('“그냥 빨리 내려와.”',()=>{this.toast('학생이 고개를 젓는다. 조금 더 진심을 담아야 한다.');})
      ],'sad');
    }
    finalFrame() {
      if(this.state.challenge.blue<3||this.state.challenge.green<1){this.toast(`조각이 부족하다. 파랑 ${this.state.challenge.blue}/3 · 초록 ${this.state.challenge.green}/1`);return;}
      this.say('빈 액자','신비','지금까지 모은 조각이 공중에 떠오른다. 파란 조각 세 개와 초록 동그라미가 빈 액자에 정확히 들어맞는다.',[
        this.choice('조각을 조립한다',()=>{this.state.challenge.frameDone=true;this.closeDialogue();this.flash();this.audio.success();this.finalStair();})
      ],'neutral');
    }
    finalStair() {
      this.finalDeadline=Date.now()+60000; this.clearHotspots(); this.renderer.set('void'); this.setObjective('1분 안에 나타난 계단 끝 문까지 올라가세요.');
      this.addHotspot({x:50,y:47,title:'빛나는 계단',sub:'사라지기 전에 올라가기',action:()=>{if(Date.now()>this.finalDeadline){this.toast('계단이 사라졌다!');this.rooftop();return;}this.startMash();},kind:'gold'});
    }
    startMash() {
      this.clearHotspots(); this.openModal(refs.quickTimeModal); let count=0; refs.quickFill.style.width='0%'; refs.mashCount.textContent='0 / 50'; refs.quickText.textContent='문을 마우스 좌클릭으로 50번 두드리세요.';
      if(this.mashHandler) refs.mashBtn.removeEventListener('click',this.mashHandler);
      const handler=()=>{count++;this.audio.tone(210+count*2,.025,'square',.012);refs.mashCount.textContent=`${count} / 50`;refs.quickFill.style.width=`${count*2}%`;if(count>=50){refs.mashBtn.removeEventListener('click',handler);this.mashHandler=null;this.closeModal(refs.quickTimeModal);this.finalDoorWindow();}};
      this.mashHandler=handler; refs.mashBtn.addEventListener('click',handler);
    }
    finalDoorWindow() {
      const deadline=Date.now()+5000; this.setObjective('문이 열렸다! 5초 안에 들어가세요.'); this.renderer.set('void');
      const b=this.addHotspot({x:50,y:48,title:'✨ 열린 문으로 들어가기',sub:'5초 제한',action:()=>{if(Date.now()<=deadline)this.trueEnding();else{this.toast('문이 닫혀버렸다.');this.rooftop();}},kind:'gold'});
      setTimeout(()=>{if(document.body.contains(b)){b.remove();this.toast('5초가 지나 문이 닫혔다.');this.rooftop();}},5100);
    }
    trueEnding() {
      this.flash();this.audio.success();this.save(false);this.showEnding({kicker:'TRUE ENDING',title:'현실로',text:`눈부신 빛이 터지고, ${this.state.name}와 ${this.state.normal.friendName}은 함께 현실로 돌아온다. 뒤를 돌아보자 학교는 아무 일도 없었다는 듯 조용히 문을 닫는다.`,reward:'★ 찐엔딩 달성',actions:[['저장하고 로비로',()=>this.returnTitle()],['처음부터',()=>this.newGame()]]});
    }

    startCombat({name,hp,attack,onDefeat,unbeatable=false,smart=false}) {
      this.currentCombat={name,hp,maxHp:hp,attack,onDefeat,unbeatable,smart,supportUsed:false};
      this.renderCombat();
    }
    renderCombat() {
      const e=this.currentCombat;if(!e)return;
      const pct=Math.max(0,Math.round(e.hp/e.maxHp*100));
      const combatChoices=[
        this.choice(`⚔ 공격 (${this.state.attack})`,()=>this.combatAttack()),
        this.choice('🛡 방어',()=>this.combatDefend())
      ];
      if(this.state.normal.friendName && !e.supportUsed && this.state.difficulty!=='easy') combatChoices.push(this.choice(`👥 ${this.state.normal.friendName} 지원`,()=>this.combatFriendSupport()));
      combatChoices.push(this.choice('🏃 전투에서 이탈',()=>{if(e.unbeatable){this.closeDialogue();this.state.easy.cafeteriaClosed=true;this.enterEasyHall();}else{this.closeDialogue();this.toast('간신히 전투에서 빠져나왔다.');this.routeByScene();}}));
      this.say(e.name,'전투',`적 HP ${e.hp} / ${e.maxHp} (${pct}%)<br>플레이어 HP ${this.state.hp} / ${this.state.maxHp}<br><small>턴 순서: 플레이어 → 귀신</small>`,combatChoices,'ghost');
    }
    combatAttack() {
      const e=this.currentCombat;if(!e)return;
      if(e.unbeatable){this.audio.danger();this.instantKill('아무리 좋은 무기라도 영양사 귀신에게는 통하지 않았다.');return;}
      const variance=.88+Math.random()*.24; const dmg=Math.max(1,Math.round(this.state.attack*variance)); e.hp-=dmg; this.audio.tone(155,.06,'sawtooth',.028);
      if(e.hp<=0){const cb=e.onDefeat;this.currentCombat=null;this.closeDialogue();this.audio.success();this.toast(`${e.name}을(를) 물리쳤다!`);setTimeout(()=>cb&&cb(),450);return;}
      const enemyDmg=e.attack; this.takeDamage(enemyDmg,`${e.name}의 반격!`,false); if(this.state.hp>0)this.renderCombat();
    }
    combatFriendSupport() {
      const e=this.currentCombat;if(!e||!this.state.normal.friendName)return;
      e.supportUsed=true;
      const dmg=Math.max(25,Math.round(this.state.attack*.7));
      e.hp-=dmg;
      this.audio.success();
      this.toast(`${this.state.normal.friendName}의 지원 공격! -${dmg}`);
      if(e.hp<=0){const cb=e.onDefeat;this.currentCombat=null;this.closeDialogue();setTimeout(()=>cb&&cb(),350);return;}
      this.renderCombat();
    }
    combatDefend() {
      const e=this.currentCombat;if(!e)return; const dmg=Math.max(1,Math.floor(e.attack*.35)); this.takeDamage(dmg,'방어로 피해를 줄였다.',false); if(this.state.hp>0)this.renderCombat();
    }
    takeDamage(amount,msg='공격당했다.',route=true) {
      if(this.state.armor>0){const absorb=Math.min(this.state.armor,Math.ceil(amount*.25));this.state.armor-=absorb;amount-=absorb;}
      this.state.hp=clamp(this.state.hp-amount,0,this.state.maxHp);this.state.mood='고통';this.updateHUD();this.hitEffect();this.toast(`${msg} -${amount} HP`);
      if(this.state.hp<=0){setTimeout(()=>this.loseLife(),420);return;}
      if(route)setTimeout(()=>this.routeByScene(),650);
    }
    instantKill(msg){this.state.hp=0;this.updateHUD();this.hitEffect(true);this.toast(msg);setTimeout(()=>this.loseLife(),600);}
    loseLife() {
      this.closeDialogue();this.currentCombat=null;this.state.lives--;
      if(this.state.lives<=0){this.showEnding({kicker:'GAME OVER',title:'학교의 어둠',text:'남은 목숨을 모두 잃었다. 마지막 체크포인트부터 다시 시작할 수 있다.',actions:[['체크포인트 재시작',()=>this.restartCheckpoint()],['로비로',()=>this.returnTitle()]]});return;}
      this.state.hp=this.state.maxHp;this.state.mood='겁먹음'; if(this.state.difficulty==='challenge'){this.state.inventory=this.state.inventory.filter(i=>i==='손전등'?false:true);this.state.weapon='없음';}
      this.updateHUD();this.toast(`목숨 하나를 잃었다. 남은 목숨 ${this.state.lives}`);setTimeout(()=>this.restartCheckpoint(),700);
    }
    restartCheckpoint() {
      refs.endingModal.classList.add('hidden');
      if(this.state.checkpoint==='easyHall')this.enterEasyHall();else if(this.state.checkpoint==='normalEntry')this.enterNormalEntry();else if(this.state.checkpoint==='challengeEntry')this.enterChallengeEntry();else this.enterGate();
    }
    routeByScene() {
      const s=this.state.scene;
      if(['easyHall','cafeteria','toilet'].includes(s)&&this.state.difficulty==='easy')this.enterEasyHall();
      else if(this.state.difficulty==='normal')this.enterNormalHall();
      else if(this.state.difficulty==='challenge'){
        if(['challengeEntry'].includes(s))this.enterChallengeEntry();else if(['english','stairs'].includes(s))this.challengeFloor1();else if(s==='math')this.challengeFloor2();else if(s==='pe')this.challengeFloor3();else if(s==='rooftop'||s==='void')this.rooftop();
      }
    }

    choice(label,fn,danger=false){return{label,fn,danger};}
    say(speaker,emotion,text,choices=[],portrait='neutral') {
      refs.dialogueSpeaker.textContent=speaker; refs.dialogueEmotion.textContent=emotion; refs.dialogueText.innerHTML=text; refs.choiceGrid.innerHTML=''; refs.dialoguePortrait.dataset.portrait=portrait;
      choices.forEach(ch=>{const b=document.createElement('button');b.className='choice'+(ch.danger?' choice--danger':'');b.textContent=ch.label;b.addEventListener('click',()=>{this.audio.click();ch.fn();});refs.choiceGrid.appendChild(b);}); refs.dialogueBox.classList.remove('hidden');
    }
    closeDialogue(){refs.dialogueBox.classList.add('hidden');refs.choiceGrid.innerHTML='';}

    completeDifficulty(title,next) {
      this.save(false); this.showEnding({kicker:'CLEAR',title,text:'진행 상황이 저장되었습니다. 다음 난이도로 이어가거나 로비로 돌아갈 수 있습니다.',actions:[['저장하고 끝내기',()=>this.returnTitle()],['다음 난이도 가기',()=>{refs.endingModal.classList.add('hidden');if(next==='normal')this.beginNormal();else this.beginChallenge();}]]});
    }

    showEnding({kicker='ENDING',title,text,reward='',actions=[]}) {
      this.closeDialogue();this.clearHotspots();refs.endingKicker.textContent=kicker;refs.endingTitle.textContent=title;refs.endingText.innerHTML=text;refs.endingReward.textContent=reward;refs.endingReward.classList.toggle('hidden',!reward);refs.endingActions.innerHTML='';
      actions.forEach(([label,fn],i)=>{const b=document.createElement('button');b.className='btn '+(i===0?'btn--primary':'btn--ghost');b.textContent=label;b.addEventListener('click',()=>{this.audio.click();fn();});refs.endingActions.appendChild(b);});refs.endingModal.classList.remove('hidden');
    }
    returnTitle(){this.save(false);refs.endingModal.classList.add('hidden');this.closeAllModals();this.showScreen('title');}

    askName(title,desc,defaultValue='') {
      refs.nameModalTitle.textContent=title;refs.nameModalDescription.textContent=desc;refs.nameModalInput.value=defaultValue;this.openModal(refs.nameModal);setTimeout(()=>refs.nameModalInput.focus(),50);
      return new Promise(resolve=>{this.nameResolver=resolve;});
    }
    resolveName(){if(!this.nameResolver)return;const val=refs.nameModalInput.value.trim()||'이름없음';const resolve=this.nameResolver;this.nameResolver=null;this.closeModal(refs.nameModal);resolve(val);}

    openModal(modal){refs.modalBackdrop.classList.remove('hidden');modal.classList.remove('hidden');}
    closeModal(modal){modal.classList.add('hidden'); if([refs.lockModal,refs.settingsModal,refs.nameModal,refs.quickTimeModal].every(m=>m.classList.contains('hidden')))refs.modalBackdrop.classList.add('hidden');}
    closeAllModals(){[refs.lockModal,refs.settingsModal,refs.nameModal,refs.quickTimeModal].forEach(m=>m.classList.add('hidden'));refs.modalBackdrop.classList.add('hidden');}
    openSettings(){refs.soundToggle.checked=this.state.settings.sound;refs.shakeToggle.checked=this.state.settings.shake;refs.scareSelect.value=this.state.settings.scare;refs.motionToggle.checked=this.state.settings.reducedMotion;this.openModal(refs.settingsModal);}
    applySettings(){document.body.classList.toggle('reduced-motion',!!this.state.settings.reducedMotion);if(!this.state.settings.sound)this.audio.stopAmbient();else if(refs.gameScreen.classList.contains('active'))this.audio.startAmbient();}

    toggleView(){this.state.firstPerson=!this.state.firstPerson;refs.viewToggleBtn.textContent=this.state.firstPerson?'시점: 캐릭터':'시점: 플레이어';refs.sceneCanvas.style.transform=this.state.firstPerson?'scale(1.03)':'scale(1)';this.toast(this.state.firstPerson?'캐릭터 시점으로 전환':'플레이어 시점으로 전환');}
    toggleFullscreen(){if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.();}
    setObjective(t){refs.objectiveLabel.textContent=t;}

    addItems(items){for(const item of items)if(!this.state.inventory.includes(item))this.state.inventory.push(item);this.updateHUD();}
    removeItem(item){const i=this.state.inventory.indexOf(item);if(i>=0)this.state.inventory.splice(i,1);this.updateHUD();}
    updateHUD(){
      refs.hudName.textContent=this.state.name;refs.hudMood.textContent=this.state.mood;refs.hpText.textContent=`${this.state.hp} / ${this.state.maxHp}`;refs.hpFill.style.width=`${(this.state.hp/this.state.maxHp)*100}%`;refs.livesDisplay.textContent='♥'.repeat(Math.max(0,this.state.lives));refs.attackText.textContent=this.state.attack;refs.weaponText.textContent=this.state.weapon;refs.armorText.textContent=this.state.armor;refs.keyText.textContent=this.state.keys;refs.inventoryMini.innerHTML=this.state.inventory.slice(-5).map(i=>`<span class="inv-chip">${i}</span>`).join('');this.applyAvatarToHud();
    }

    flash(){refs.flashLayer.classList.remove('flash');void refs.flashLayer.offsetWidth;refs.flashLayer.classList.add('flash');}
    hitEffect(strong=false){if(this.state.settings.shake){document.body.classList.remove('shake');void document.body.offsetWidth;document.body.classList.add('shake');setTimeout(()=>document.body.classList.remove('shake'),420);}if(strong)this.flash();this.audio.danger();}
    jumpScare(full=true){if(this.state.settings.scare==='soft'){this.hitEffect(false);return;}this.hitEffect(full);const layer=document.createElement('div');layer.className='scare-face';layer.innerHTML='<div class="scare-face__head"></div>';document.body.appendChild(layer);setTimeout(()=>layer.remove(),650);}

    toast(msg){clearTimeout(this.toastTimer);refs.toast.textContent=msg;refs.toast.classList.add('show');this.toastTimer=setTimeout(()=>refs.toast.classList.remove('show'),2200);}

    save(showToast=true){
      try{localStorage.setItem('schoolEscapeStoreSave',JSON.stringify(this.state));localStorage.setItem('schoolEscapeAchievements',JSON.stringify(this.state.achievements));if(showToast)this.toast('저장되었습니다.');this.updateContinueButton();}catch{if(showToast)this.toast('저장에 실패했습니다.');}
    }
    load(){
      try{const raw=localStorage.getItem('schoolEscapeStoreSave');if(!raw){this.toast('저장된 게임이 없습니다.');return;}const data=JSON.parse(raw);this.state={...DEFAULT_STATE(),...data,appearance:{...DEFAULT_STATE().appearance,...data.appearance},settings:{...DEFAULT_STATE().settings,...data.settings},easy:{...DEFAULT_STATE().easy,...data.easy},normal:{...DEFAULT_STATE().normal,...data.normal},challenge:{...DEFAULT_STATE().challenge,...data.challenge},achievements:{...DEFAULT_STATE().achievements,...data.achievements}};this.applySettings();this.showScreen('game');this.updateHUD();this.resumeScene();this.toast('저장 데이터를 불러왔습니다.');}catch{this.toast('저장 데이터가 손상되었습니다.');}
    }
    resumeScene(){
      if(this.state.difficulty==='easy')this.enterEasyHall();else if(this.state.difficulty==='normal'){if(this.state.normal.goldenKey||this.state.normal.principalKills>0)this.enterNormalHall();else this.enterNormalEntry();}else if(this.state.difficulty==='challenge'){if(this.state.challenge.rooftopDone||this.state.challenge.frameDone)this.rooftop();else if(this.state.challenge.peDone)this.challengeFloor3();else if(this.state.challenge.mathDone)this.challengeFloor2();else if(this.state.challenge.cerberusDone)this.challengeFloor1();else this.enterChallengeEntry();}else if(this.state.scene==='lobby')this.enterLobby();else this.enterGate();
    }
    updateContinueButton(){let has=false;try{has=!!localStorage.getItem('schoolEscapeStoreSave');}catch{}$('continueBtn').disabled=!has;$('continueBtn').style.opacity=has?'1':'.45';}
  }

  const game = new Game();
  window.__schoolEscapeGame = game;
})();
